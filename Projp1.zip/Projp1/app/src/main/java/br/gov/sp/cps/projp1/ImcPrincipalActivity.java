package br.gov.sp.cps.projp1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ImcPrincipalActivity extends AppCompatActivity {
    private EditText nome;

    private EditText peso;

    private EditText altura;

    private Button btn_calcular;

    private Button btn_voltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.imcprincipal);
        nome = findViewById(R.id.editTextNome);
        peso = findViewById(R.id.editTextPeso);
        altura = findViewById(R.id.editTextAltura);
        btn_calcular = findViewById(R.id.btnCalcular);
        btn_voltar = findViewById(R.id.btnVoltar);
        btn_calcular.setOnClickListener(view -> {
                    String valorNome = nome.getText().toString();
                    double valorPeso = Double.parseDouble(peso.getText().toString());
                    double valorAltura = Double.parseDouble(altura.getText().toString());

                    double imc = valorPeso / Math.pow(valorAltura, 2.0);
                    Intent intent;

                    if (imc > 0 && imc < 18.5) {
                        intent = new Intent(this, Imc2Activity.class);
                        intent.putExtra("msg", "Abaixo do peso! Procure um médico ou nutricionista.");
                    } else if (imc >= 18.5 && imc < 25.0) {
                        intent = new Intent(this, Imc3Activity.class);
                        intent.putExtra("msg", "Peso normal! Não é necessário nenhuma assistência profissional.");
                    } else if (imc >= 25.0 && imc < 30.0) {
                        intent = new Intent(this, Imc4Activity.class);
                        intent.putExtra("msg", "Sobrepeso! Considere buscar assistência profissional.");
                    } else if (imc >= 30.0 && imc < 35.0) {
                        intent = new Intent(this, Imc5Activity.class);
                        intent.putExtra("msg", "Obesidade Grau I! Procure assistência profissional.");
                    } else if (imc >= 35.0 && imc < 40.0) {
                        intent = new Intent(this, Imc6Activity.class);
                        intent.putExtra("msg", "Obesidade Grau II, Estado Severo! Procure um profissional imediatamente.");
                    } else {
                        intent = new Intent(this, Imc7Activity.class);
                        intent.putExtra("msg", "Obesidade Grau III, Estado Crítico (risco de morte)! Procure um profissional imediatamente.");
                    }
                    intent.putExtra("nome", valorNome);
                    intent.putExtra("peso", String.format("%.2f", valorPeso));
                    intent.putExtra("altura", String.format("%.2f", valorAltura));
                    intent.putExtra("imc", String.format("%.2f", imc));
                    startActivity(intent);
                });
        btn_voltar.setOnClickListener(view -> {
            finish();
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}