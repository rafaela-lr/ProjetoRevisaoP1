package br.gov.sp.cps.projp1;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class JokenPoActivity extends AppCompatActivity {
    private int placarPC = 0;
    private int placarPlayer = 0;
    private boolean jogoAtivo = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.jokenpo);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void selecPedra(View view){
        if (jogoAtivo) this.opcaoSelecionada("pedra");
    }

    public void selecPapel(View view){
        if (jogoAtivo) this.opcaoSelecionada("papel");
    }

    public void selecTesoura(View view){
        if (jogoAtivo) this.opcaoSelecionada("tesoura");
    }

    public void reiniciarJogo(View view) {
        placarPC = 0;
        placarPlayer = 0;
        jogoAtivo = true;

        TextView textResultado = findViewById(R.id.textResultado);
        textResultado.setText("...");
        textResultado.setTextSize(32); // Volta ao tamanho original (em sp)

        ImageView imgResultado = findViewById(R.id.imgResultado);
        imgResultado.setImageResource(R.drawable.padrao);

        atualizarPlacar();

        // Resetar opacidade das opções
        findViewById(R.id.optionsLayout).setAlpha(1.0f);
    }

    private void atualizarPlacar() {
        TextView textPlacarPC = findViewById(R.id.textPlacarPC);
        TextView textPlacarPlayer = findViewById(R.id.textPlacarPlayer);

        textPlacarPC.setText(String.valueOf(placarPC));
        textPlacarPlayer.setText(String.valueOf(placarPlayer));
    }

    public void opcaoSelecionada(String opcaoSelecionada) {
        ImageView imgResultado = findViewById(R.id.imgResultado);
        TextView textResultado = findViewById(R.id.textResultado);

        int numero = new Random().nextInt(3);
        String[] opcoes = {"pedra", "papel", "tesoura"};
        String opcaoPC = opcoes[numero];

        switch (opcaoPC) {
            case "pedra":
                imgResultado.setImageResource(R.drawable.pedra);
                break;
            case "papel":
                imgResultado.setImageResource(R.drawable.papel);
                break;
            case "tesoura":
                imgResultado.setImageResource(R.drawable.tesoura);
                break;
        }

        if (
                (opcaoPC.equals("tesoura") && opcaoSelecionada.equals("papel")) ||
                        (opcaoPC.equals("papel") && opcaoSelecionada.equals("pedra")) ||
                        (opcaoPC.equals("pedra") && opcaoSelecionada.equals("tesoura"))
        ) {
            textResultado.setText("perdeu!");
            placarPC++;
        } else if (
                (opcaoSelecionada.equals("tesoura") && opcaoPC.equals("papel")) ||
                        (opcaoSelecionada.equals("papel") && opcaoPC.equals("pedra")) ||
                        (opcaoSelecionada.equals("pedra") && opcaoPC.equals("tesoura"))
        ) {
            textResultado.setText("ganhou!");
            placarPlayer++;
        } else {
            textResultado.setText("empatou!");
        }

        atualizarPlacar();

        // Verificar se alguém atingiu 5 pontos
        if (placarPC == 5 || placarPlayer == 5) {
            jogoAtivo = false;
            String msg = (placarPC == 5) ? "PC Campeão!\nReinicie o jogo." : "Você Campeão!\nReinicie o jogo.";
            textResultado.setText(msg);
            textResultado.setTextSize(24); // Reduz um pouco para caber a mensagem completa

            // Feedback visual: escurece as opções para indicar que estão desativadas
            findViewById(R.id.optionsLayout).setAlpha(0.3f);
        }
    }

    public void voltar(View view){
        finish();
    }
}