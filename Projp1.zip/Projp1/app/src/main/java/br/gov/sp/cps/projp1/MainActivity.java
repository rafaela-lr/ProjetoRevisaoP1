package br.gov.sp.cps.projp1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private Button buttonIMC;

    private Button buttonMegaSena;

    private Button buttonJokenPo;

    private Button buttonQuestionario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        buttonIMC = findViewById(R.id.buttonIMC);
        buttonMegaSena = findViewById(R.id.buttonMegaSena);
        buttonJokenPo = findViewById(R.id.buttonJokenPo);
        buttonQuestionario = findViewById(R.id.buttonQuestionario);

        buttonIMC.setOnClickListener(view -> {
            Intent intent = new Intent(this, ImcPrincipalActivity.class);
            startActivity(intent);
        });

        buttonMegaSena.setOnClickListener(view -> {
            Intent intent = new Intent(this, MegaSenaActivity.class);
            startActivity(intent);
        });

        buttonJokenPo.setOnClickListener(view -> {
            Intent intent = new Intent(this, JokenPoActivity.class);
            startActivity(intent);
        });

        buttonQuestionario.setOnClickListener(view -> {
            Intent intent = new Intent(this, QuestionarioActivity.class);
            startActivity(intent);
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}