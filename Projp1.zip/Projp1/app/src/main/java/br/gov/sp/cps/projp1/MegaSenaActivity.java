package br.gov.sp.cps.projp1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class MegaSenaActivity extends AppCompatActivity {
    private TextView[] camposNumeros = new TextView[6];
    private Button btnSorteio, btnLimpar, btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.megasena);
        camposNumeros[0] = findViewById(R.id.num1);
        camposNumeros[1] = findViewById(R.id.num2);
        camposNumeros[2] = findViewById(R.id.num3);
        camposNumeros[3] = findViewById(R.id.num4);
        camposNumeros[4] = findViewById(R.id.num5);
        camposNumeros[5] = findViewById(R.id.num6);

        btnSorteio = findViewById(R.id.btnSorteio);
        btnLimpar = findViewById(R.id.btnLimpar);
        btnVoltar = findViewById(R.id.btnVoltar);

        btnSorteio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sortearNumeros();
            }
        });

        btnLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                limparCampos();
            }
        });

        btnVoltar.setOnClickListener(view -> {
            finish();
        });
    }

    private void sortearNumeros() {
        Random random = new Random();
        Set<Integer> sorteados = new HashSet<>();

        // Gera 6 números únicos entre 1 e 60
        while (sorteados.size() < 6) {
            int numero = random.nextInt(60) + 1;
            sorteados.add(numero);
        }

        List<Integer> listaOrdenada = new ArrayList<>(sorteados);
        Collections.sort(listaOrdenada);


        for (int i = 0; i < 6; i++) {
            camposNumeros[i].setText(String.format("%02d", listaOrdenada.get(i)));
        }
    }

    private void limparCampos() {
        for (TextView tv : camposNumeros) {
            tv.setText("--");
        }
    }
}