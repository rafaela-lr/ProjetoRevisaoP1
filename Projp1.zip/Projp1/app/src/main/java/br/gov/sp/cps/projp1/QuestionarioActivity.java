package br.gov.sp.cps.projp1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class QuestionarioActivity extends AppCompatActivity {

    private RadioGroup rgSono, rgEstresse;
    private Button btnCalcular, btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questionario);

        rgSono = findViewById(R.id.rgSono);
        rgEstresse = findViewById(R.id.rgEstresse);
        btnCalcular = findViewById(R.id.btnCalcular);
        btnVoltar = findViewById(R.id.btnVoltar);

        btnCalcular.setOnClickListener(v -> {
            int sonoId = rgSono.getCheckedRadioButtonId();
            int estresseId = rgEstresse.getCheckedRadioButtonId();

            if (sonoId == -1 || estresseId == -1) {
                Toast.makeText(this, "Por favor, selecione todas as opções", Toast.LENGTH_SHORT).show();
                return;
            }

            int pontuacao = 0;

            if (sonoId == R.id.rbSono03) pontuacao += 1;
            else if (sonoId == R.id.rbSono48) pontuacao += 3;
            else if (sonoId == R.id.rbSono912) pontuacao += 5;

            if (estresseId == R.id.rbEstresse03) pontuacao += 5;
            else if (estresseId == R.id.rbEstresse47) pontuacao += 2;
            else if (estresseId == R.id.rbEstresse810) pontuacao += 0;

            Intent intent = new Intent(this, ResultadoFelicidadeActivity.class);
            intent.putExtra("PONTUACAO", pontuacao);
            startActivity(intent);
        });

        btnVoltar.setOnClickListener(v -> finish());
    }
}