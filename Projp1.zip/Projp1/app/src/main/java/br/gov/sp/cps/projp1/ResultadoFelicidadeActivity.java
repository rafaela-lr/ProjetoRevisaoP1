package br.gov.sp.cps.projp1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ResultadoFelicidadeActivity extends AppCompatActivity {

    private TextView tvPontuacao, tvClassificacao;
    private Button btnVoltarResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado_felicidade);

        tvPontuacao = findViewById(R.id.tvPontuacao);
        tvClassificacao = findViewById(R.id.tvClassificacao);
        btnVoltarResultado = findViewById(R.id.btnVoltarResultado);

        int pontuacao = getIntent().getIntExtra("PONTUACAO", 0);

        tvPontuacao.setText("Pontuação: " + pontuacao);

        String classificacao;
        if (pontuacao >= 8) {
            classificacao = "Muito Feliz";
        } else if (pontuacao >= 5) {
            classificacao = "Feliz";
        } else if (pontuacao >= 3) {
            classificacao = "Regular";
        } else {
            classificacao = "Infeliz";
        }

        tvClassificacao.setText("Classificação: " + classificacao);

        btnVoltarResultado.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
        });
    }
}